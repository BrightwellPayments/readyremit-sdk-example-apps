package com.readyremitsdk

import com.facebook.react.bridge.ReadableMap
import com.brightwell.readyremit.sdk.SourceAccount
import com.brightwell.readyremit.sdk.AuthenticationResult
import com.brightwell.readyremit.sdk.Localization
import com.brightwell.readyremit.sdk.ReadyRemitConfiguration
import com.brightwell.readyremit.sdk.ReadyRemitEnvironment
import com.brightwell.readyremit.sdk.ReadyRemitEventListener
import com.brightwell.readyremit.sdk.ReadyRemitTransferRequest
import com.brightwell.readyremit.sdk.RemittanceServiceProvider
import com.brightwell.readyremit.sdk.SupportedAppearance
import com.brightwell.readyremit.sdk.TransferSubmissionResult
import com.brightwell.readyremit.sdk.TransferType
import com.brightwell.readyremit.sdk.core.domain.model.CountryIso3Code
import org.json.JSONObject
import java.math.BigDecimal

/**
 * Utility to convert a React Native configuration map into the Android SDK ReadyRemitConfiguration.
 * Updated to support the new configuration model with appearance JSON and supportedAppearance.
 */
object ConfigurationConverter {

  /**
   * Convert a ReadableMap to SDK ReadyRemitConfiguration by delegating to the Map-based variant.
   */
  fun convert(
      readable: ReadableMap,
      authenticate: suspend () -> AuthenticationResult,
      submit: suspend (ReadyRemitTransferRequest) -> TransferSubmissionResult,
      listener: ReadyRemitEventListener? = null
  ): ReadyRemitConfiguration {
    return convert(readable.toHashMap(), authenticate, submit, listener)
  }

  /**
   * Convert a Map<String, Any?> (from JS) to SDK ReadyRemitConfiguration.
   * Provides safe defaults where appropriate and tolerates missing/invalid values.
   */
  fun convert(
    config: Map<String, Any?>,
    authenticate: suspend () -> AuthenticationResult,
    submit: suspend (ReadyRemitTransferRequest) -> TransferSubmissionResult,
    listener: ReadyRemitEventListener? = null
  ): ReadyRemitConfiguration {
    val appearance = extractAppearanceJSON(config)
    val defaultCountry = convertDefaultCountry(config["defaultCountry"] as? String)
    val idleTimeoutInterval = (config["idleTimeoutInterval"] as? Number)?.toLong()
    val environment = convertEnvironment(config["environment"])
    val fixedProvider = convertRemittanceServiceProvider(config["remittanceServiceProvider"] as? String)
    val fixedTransferType = convertTransferType(config["transferMethod"] as? String)
    val localization = convertLocalization(config["localization"])
    val sourceAccounts = convertSourceAccounts(config["sourceAccounts"] as? List<*>)
    val supportedAppearance = convertSupportedAppearance(config["supportedAppearance"] as? String)

    return ReadyRemitConfiguration(
      appearance = appearance,
      defaultCountry = defaultCountry,
      idleTimeoutInterval = idleTimeoutInterval,
      environment = environment,
      fixedRemittanceServiceProvider = fixedProvider,
      fixedTransferMethod = fixedTransferType,
      localization = localization,
      sourceAccounts = sourceAccounts,
      supportedAppearance = supportedAppearance,
      authenticateIntoTheSdk = authenticate,
      submitTransfer = submit,
      sdkEventListener = listener
    )
  }

  /**
   * Extracts the appearance configuration as a JSON string from the config map.
   * Returns null if appearance is not provided or is invalid.
   */
  private fun extractAppearanceJSON(config: Map<String, Any?>): String? {
    val appearance = config["appearance"] as? Map<*, *> ?: return null
    return try {
      JSONObject(appearance).toString()
    } catch (e: Exception) {
      null
    }
  }

  /** Convert TS environment string to SDK ReadyRemitEnvironment. */
  private fun convertEnvironment(env: Any?): ReadyRemitEnvironment {
    val str = (env as? String)?.trim() ?: return ReadyRemitEnvironment.SANDBOX
    return when (str.lowercase()) {
      "production" -> ReadyRemitEnvironment.PRODUCTION
      "sandbox" -> ReadyRemitEnvironment.SANDBOX
      else -> when (str.uppercase()) {
        "PRODUCTION" -> ReadyRemitEnvironment.PRODUCTION
        "SANDBOX" -> ReadyRemitEnvironment.SANDBOX
        else -> ReadyRemitEnvironment.SANDBOX
      }
    }
  }

  /** Convert TS localization string to SDK Localization. */
  private fun convertLocalization(locale: Any?): Localization {
    val str = (locale as? String)?.trim() ?: return Localization.enUS
    return when (str.replace("-", "").lowercase()) {
      "enus" -> Localization.enUS
      "esmx" -> Localization.esMX
      else -> Localization.enUS
    }
  }

  /** Convert TS transfer method string to SDK TransferType. */
  private fun convertTransferType(transfer: String?): TransferType? {
    return when (transfer) {
      "bankAccount" -> TransferType.BANK_ACCOUNT
      "cashPickup" -> TransferType.CASH_PICKUP
      "mobileWallet" -> TransferType.MOBILE_WALLET
      "pushToCard" -> TransferType.PUSH_TO_CARD
      else -> null
    }
  }

  /** Convert TS remittance provider string to SDK RemittanceServiceProvider. */
  private fun convertRemittanceServiceProvider(provider: String?): RemittanceServiceProvider? {
    return when (provider?.lowercase()) {
      "convera" -> RemittanceServiceProvider.CONVERA
      "mastercard" -> RemittanceServiceProvider.MASTERCARD
      "moneygram", "moneyGram" -> RemittanceServiceProvider.MONEYGRAM
      "visa" -> RemittanceServiceProvider.VISA
      else -> null
    }
  }

  /** Convert TS default country string (ISO-3) to SDK CountryIso3Code. */
  private fun convertDefaultCountry(country: String?): CountryIso3Code? {
    val code = country?.trim()?.takeIf { it.length == 3 }
    return code?.let { CountryIso3Code.find(it) }
  }

  /** Convert TS supported appearance string to SDK SupportedAppearance. */
  private fun convertSupportedAppearance(appearance: String?): SupportedAppearance {
    return when (appearance?.lowercase()) {
      "light" -> SupportedAppearance.Light
      "dark" -> SupportedAppearance.Dark
      "device" -> SupportedAppearance.Device
      else -> SupportedAppearance.Device
    }
  }

  /** Convert TS source accounts array to SDK SourceAccount list. */
  private fun convertSourceAccounts(list: List<*>?): List<SourceAccount>? {
    val maps = list ?: return null
    val result = mutableListOf<SourceAccount>()
    for (item in maps) {
      val m = item as? Map<*, *> ?: continue
      val alias = m["alias"] as? String ?: continue
      val balanceNum = m["balance"] as? Number ?: continue
      val last4 = m["last4"] as? String ?: continue
      val sourceProviderId = m["sourceProviderId"] as? String ?: continue
      result.add(
        SourceAccount(
          alias = alias,
          balance = BigDecimal(balanceNum.toDouble()),
          last4 = last4,
          sourceProviderId = sourceProviderId
        )
      )
    }
    return result.takeIf { it.isNotEmpty() }
  }
}
