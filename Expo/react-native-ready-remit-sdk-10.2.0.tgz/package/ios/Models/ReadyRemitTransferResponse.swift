//
//  ReadyRemitTransferResponse.swift
//  Pods
//
//  Created by Lucas Bordini on 11/7/25.
//

import ReadyRemitSDK

struct ReadyRemitTransferResponse: ReadyRemitSDK.TransferDetails {
  let transferId: String
}
