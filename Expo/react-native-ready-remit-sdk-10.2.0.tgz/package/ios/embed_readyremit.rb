# Embeds ReadyRemitSDK SPM dynamic frameworks into the app bundle.
#
# CocoaPods' SPM integration links SPM packages to pod targets but does not
# automatically embed dynamic frameworks in the host app. This helper adds a
# build phase that copies all required SPM frameworks (ReadyRemitSDK and its
# dependencies like VisaSensoryBranding) into the app bundle at runtime.
#
# Usage — add to your Podfile:
#
#   require_relative '../node_modules/react-native-ready-remit-sdk/ios/embed_readyremit'
#
#   post_install do |installer|
#     react_native_post_install(installer, ...)
#     embed_readyremit_framework!(installer)
#   end

READYREMIT_SPM_FRAMEWORKS = %w[
  ReadyRemitSDK
  VisaSensoryBranding
].freeze

def embed_readyremit_framework!(installer)
  phase_name = '[ReadyRemit] Embed SPM Frameworks'

  installer.aggregate_targets.each do |aggregate_target|
    project = aggregate_target.user_project
    next unless project

    project.targets.each do |target|
      next unless target.respond_to?(:product_type)
      next unless target.product_type == 'com.apple.product-type.application'

      existing = target.shell_script_build_phases.find { |p| p.name == phase_name }
      existing&.remove_from_project

      phase = target.new_shell_script_build_phase(phase_name)
      frameworks_list = READYREMIT_SPM_FRAMEWORKS.map { |f| "\"#{f}\"" }.join(' ')
      phase.shell_script = <<~SCRIPT
        DEST="${BUILT_PRODUCTS_DIR}/${FRAMEWORKS_FOLDER_PATH}"
        FRAMEWORKS=(#{frameworks_list})

        mkdir -p "$DEST"

        for FWNAME in "${FRAMEWORKS[@]}"; do
          # Search in multiple locations where SPM may place built frameworks
          SRC=""
          for SEARCH_DIR in \\
            "${BUILT_PRODUCTS_DIR}/PackageFrameworks" \\
            "${BUILT_PRODUCTS_DIR}" \\
            "${BUILT_PRODUCTS_DIR}/RNReadyRemitSdk" \\
            "${BUILT_PRODUCTS_DIR}/ReadyRemitSdk"; do
            if [ -d "${SEARCH_DIR}/${FWNAME}.framework" ]; then
              SRC="${SEARCH_DIR}/${FWNAME}.framework"
              break
            fi
          done

          if [ -z "$SRC" ]; then
            echo "warning: ${FWNAME}.framework not found — SDK may crash at launch."
            continue
          fi

          rsync -av --delete "$SRC" "$DEST/"

          if [ "${CODE_SIGNING_REQUIRED:-}" == "YES" ] && [ -n "${EXPANDED_CODE_SIGN_IDENTITY:-}" ]; then
            /usr/bin/codesign --force --sign "${EXPANDED_CODE_SIGN_IDENTITY}" --preserve-metadata=identifier,entitlements "${DEST}/${FWNAME}.framework"
          fi
        done
      SCRIPT

      Pod::UI.puts "ReadyRemit: Added '#{phase_name}' build phase to #{target.name}".green
    end

    project.save
  end
end
