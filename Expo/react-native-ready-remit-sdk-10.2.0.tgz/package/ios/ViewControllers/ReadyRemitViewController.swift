//
//  ReadyRemitViewController.swift
//  ReactNative
//
//  Created by Lucas Bordini on 9/18/25.
//

import UIKit
import ReadyRemitSDK
import SwiftUI

class ReadyRemitViewController: UIViewController {

  let configuration: ReadyRemitConfiguration
  let themeConfiguration: String?
  let fetchAccessTokenDetails: () async throws -> AccessTokenDetails
    let verifyFundsAndCreateTransfer: (ReadyRemitSDK.TransferRequest) async throws(ReadyRemitSDK.ReadyRemitError) -> ReadyRemitTransferResponse
  let onLaunch: () -> Void
  let onDismiss: () -> Void

  init(
    configuration: ReadyRemitConfiguration,
    themeConfiguration: String? = nil,
    fetchAccessTokenDetails: @escaping () async throws -> AccessTokenDetails,
    verifyFundsAndCreateTransfer: @escaping (ReadyRemitSDK.TransferRequest) async throws(ReadyRemitSDK.ReadyRemitError) -> ReadyRemitTransferResponse,
    onLaunch: @escaping () -> Void,
    onDismiss: @escaping () -> Void
  ) {
    self.configuration = configuration
    self.themeConfiguration = themeConfiguration
    self.fetchAccessTokenDetails = fetchAccessTokenDetails
    self.verifyFundsAndCreateTransfer = verifyFundsAndCreateTransfer
    self.onLaunch = onLaunch
    self.onDismiss = onDismiss

    super.init(nibName: nil, bundle: nil)
  }

  required init?(coder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }

  override func viewWillAppear(_ animated: Bool) {
    super.viewWillAppear(animated)
    navigationController?.setNavigationBarHidden(true, animated: animated)
  }

  public func startSDK() {
    ReadyRemit.shared.startSDK(
      configuration: configuration,
      themeConfiguration: themeConfiguration,
      fetchAccessTokenDetails: fetchAccessTokenDetails,
      verifyFundsAndCreateTransfer: verifyFundsAndCreateTransfer,
      onLaunch: { [weak self] in
        guard let self else { return }
        self.onLaunch()
      },
      onDismiss: { [weak self] in
        guard let self else { return }
        self.onDismiss()
        self.dismiss(animated: true)
      },
      onLoad: { [weak self] view in
        guard let self else { return }
        self.navigationController?.pushViewController(
          UIHostingController(rootView: view),
          animated: true
        )
      })
  }

  public func startTransferDetails(transferId: String) {
    ReadyRemit.shared.showTransfer(
      transferId: transferId,
      configuration: configuration,
      themeConfiguration: themeConfiguration,
      fetchAccessTokenDetails: fetchAccessTokenDetails,
      verifyFundsAndCreateTransfer: verifyFundsAndCreateTransfer,
      onLaunch: { [weak self] in
        guard let self else { return }
        self.onLaunch()
      },
      onDismiss: { [weak self] in
        guard let self else { return }
        self.onDismiss()
        self.dismiss(animated: true)
      },
      onLoad: { [weak self] view in
        guard let self else { return }
        self.navigationController?.pushViewController(
          UIHostingController(rootView: view),
          animated: true
        )
      })
  }

}
