import { TurboModuleRegistry, type TurboModule } from 'react-native';

export interface Spec extends TurboModule {
  startSDK(config: Object): void;
  startTransferDetails(config: Object, transferId: string): void;
  // Use plain Object for responses to avoid ObjC typed wrapper conversions
  onAccessTokenResponse(token?: Object | null, error?: Object | null): void;
  onTransferResponse(response?: Object | null, error?: Object | null): void;
  // EventEmitter contract in New Arch
  addListener(eventName: string): void;
  removeListeners(count: number): void;
}

export default TurboModuleRegistry.getEnforcing<Spec>('ReadyRemitSdk');
