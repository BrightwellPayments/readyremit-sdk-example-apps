// Expo config plugin to make ReadyRemit SDK work smoothly with Expo Prebuild/Custom Dev Client
// It enforces iOS deployment target and AndroidX/Jetifier gradle properties.
// Note: Compile/target/min SDK, Kotlin and AGP versions should be set via expo-build-properties.

const { withGradleProperties, withPodfile, withProjectBuildGradle, withAppBuildGradle, withAndroidManifest, createRunOncePlugin } = require('@expo/config-plugins');

const withReadyRemitGradleProps = (config) => {
  return withGradleProperties(config, (propsConfig) => {
    const props = propsConfig.modResults;

    const ensureProp = (key, value) => {
      const existing = props.find((p) => p.key === key);
      if (existing) {
        existing.value = String(value);
      } else {
        props.push({ type: 'property', key, value: String(value) });
      }
    };

    ensureProp('android.useAndroidX', 'true');
    ensureProp('android.enableJetifier', 'true');

    return propsConfig;
  });
};

const withReadyRemitIos = (config) => {
  config.ios = config.ios || {};
  // Ensure minimum iOS deployment target aligns with the native SDK requirements
  if (!config.ios.deploymentTarget || Number(config.ios.deploymentTarget) < 16) {
    config.ios.deploymentTarget = '16.0';
  }
  return config;
};

const withReadyRemitPodfile = (config) => {
  return withPodfile(config, (podConfig) => {
    let contents = podConfig.modResults.contents || '';

    if (!contents.includes("source 'https://cdn.cocoapods.org/'")) {
      contents = `source 'https://cdn.cocoapods.org/'\n` + contents;
    }

    if (!contents.includes('embed_readyremit')) {
      contents = `require_relative '../node_modules/react-native-ready-remit-sdk/ios/embed_readyremit'\n` + contents;
    }

    if (!contents.includes("use_frameworks! :linkage => :dynamic\n")) {
      const reactNativeMatch = contents.match(/^(\s*use_react_native!\()/m);
      if (reactNativeMatch) {
        contents = contents.replace(
          reactNativeMatch[0],
          `  use_frameworks! :linkage => :dynamic\n\n${reactNativeMatch[0]}`
        );
      }
    }

    if (!contents.includes('embed_readyremit_framework!')) {
      contents = contents.replace(
        /post_install\s+do\s+\|installer\|/,
        'post_install do |installer|\n    embed_readyremit_framework!(installer)'
      );
    }

    podConfig.modResults.contents = contents;
    return podConfig;
  });
};

const withReadyRemitAndroidManifest = (config) => {
  return withAndroidManifest(config, (manifestConfig) => {
    const manifest = manifestConfig.modResults;
    const app = manifest.manifest.application?.[0];
    if (!app) return manifestConfig;

    app.$['android:allowBackup'] = 'false';
    app.$['tools:replace'] = 'android:allowBackup';

    if (!manifest.manifest.$['xmlns:tools']) {
      manifest.manifest.$['xmlns:tools'] = 'http://schemas.android.com/tools';
    }

    return manifestConfig;
  });
};

const withReadyRemitAndroidCompose = (config) => {
  const findBlockRange = (text, startRegex) => {
    const startIdx = text.search(startRegex);
    if (startIdx === -1) return null;
    const braceStart = text.indexOf('{', startIdx);
    if (braceStart === -1) return null;
    let depth = 1;
    let inSingle = false;
    let inDouble = false;
    let inLineComment = false;
    let inBlockComment = false;
    for (let i = braceStart + 1; i < text.length; i++) {
      const ch = text[i];
      const next = text[i + 1];
      if (inLineComment) { if (ch === '\n') inLineComment = false; continue; }
      if (inBlockComment) { if (ch === '*' && next === '/') { inBlockComment = false; i++; } continue; }
      if (!inSingle && !inDouble && ch === '/' && next === '/') { inLineComment = true; i++; continue; }
      if (!inSingle && !inDouble && ch === '/' && next === '*') { inBlockComment = true; i++; continue; }
      if (!inDouble && ch === '\'') { inSingle = !inSingle; continue; }
      if (!inSingle && ch === '"') { inDouble = !inDouble; continue; }
      if (inSingle || inDouble) continue;
      if (ch === '{') depth++;
      else if (ch === '}') { depth--; if (depth === 0) return { start: braceStart, end: i }; }
    }
    return null;
  };

  const ensureComposeDependencies = (text) => {
    const range = findBlockRange(text, /dependencies\s*\{/);
    if (!range) return text;
    const inner = text.slice(range.start + 1, range.end);
    const insertionLines = [
      '  implementation platform("androidx.compose:compose-bom:2025.06.01")',
      '  implementation "androidx.compose.runtime:runtime"',
      '  implementation "androidx.compose.ui:ui"',
      '  implementation "androidx.compose.ui:ui-tooling-preview"',
      '  debugImplementation "androidx.compose.ui:ui-tooling"',
    ];
    const already = insertionLines.every((l) => inner.includes(l.trim()));
    if (already) return text;
    const before = text.slice(0, range.end);
    const after = text.slice(range.end);
    return before + '\n' + insertionLines.join('\n') + '\n' + after;
  };

  const ensureAndroidBuildFeaturesCompose = (text) => {
    const androidRange = findBlockRange(text, /android\s*\{/);
    if (!androidRange) return text;
    const androidInner = text.slice(androidRange.start + 1, androidRange.end);
    const bfRange = findBlockRange(androidInner, /buildFeatures\s*\{/);
    if (bfRange) {
      const absEnd = androidRange.start + 1 + bfRange.end;
      const bfInner = text.slice(androidRange.start + 1 + bfRange.start + 1, absEnd);
      if (/compose\s+true/.test(bfInner)) return text;
      return text.slice(0, absEnd) + '\n    compose true\n' + text.slice(absEnd);
    } else {
      const insertPos = androidRange.start + 1;
      const block = '\n  buildFeatures {\n    compose true\n  }\n';
      return text.slice(0, insertPos) + block + text.slice(insertPos);
    }
  };

  const insertIntoPluginsBlock = (text, lineRegex, lineToInsert) => {
    const pluginsRange = findBlockRange(text, /plugins\s*\{/);
    if (!pluginsRange) return text;
    const inner = text.slice(pluginsRange.start + 1, pluginsRange.end);
    if (lineRegex.test(inner)) return text;
    const before = text.slice(0, pluginsRange.end);
    const after = text.slice(pluginsRange.end);
    return before + '\n' + lineToInsert + '\n' + after;
  };

  config = withProjectBuildGradle(config, (gradleConfig) => {
    let contents = gradleConfig.modResults.contents || '';
    const rootPluginLine = '  id("org.jetbrains.kotlin.plugin.compose") version "2.1.20" apply false';
    const rootPluginRegex = /org\.jetbrains\.kotlin\.plugin\.compose/;
    const bsRange = findBlockRange(contents, /buildscript\s*\{/);
    if (bsRange) {
      const inner = contents.slice(bsRange.start + 1, bsRange.end);
      const depRange = findBlockRange(inner, /dependencies\s*\{/);
      if (depRange) {
        const absEnd = bsRange.start + 1 + depRange.end;
        const depInner = contents.slice(bsRange.start + 1 + depRange.start + 1, absEnd);
        const lines = [
          "    classpath 'org.jetbrains.kotlin:compose-compiler-gradle-plugin:2.1.20'",
          '    classpath "org.jetbrains.kotlin.plugin.compose:org.jetbrains.kotlin.plugin.compose.gradle.plugin:2.1.20"',
        ];
        const need = !lines.every((l) => depInner.includes(l.trim()));
        if (need) {
          contents = contents.slice(0, absEnd) + '\n' + lines.join('\n') + '\n' + contents.slice(absEnd);
        }
      }
    }
    const pluginsBlockRange = findBlockRange(contents, /plugins\s*\{/);
    if (pluginsBlockRange) {
      contents = insertIntoPluginsBlock(contents, rootPluginRegex, rootPluginLine);
    } else if (!rootPluginRegex.test(contents)) {
      const newBlock = `plugins {\n${rootPluginLine}\n}\n\n`;
      contents = newBlock + contents;
    }
    gradleConfig.modResults.contents = contents;
    return gradleConfig;
  });

  config = withAppBuildGradle(config, (appGradleConfig) => {
    let contents = appGradleConfig.modResults.contents || '';
    const appPluginLine = '  id("org.jetbrains.kotlin.plugin.compose")';
    const appPluginRegex = /id\(["']org\.jetbrains\.kotlin\.plugin\.compose["']\)/;
    const hadPluginsBlock = !!findBlockRange(contents, /plugins\s*\{/);
    contents = insertIntoPluginsBlock(contents, appPluginRegex, appPluginLine);
    if (!appPluginRegex.test(contents) && !/org\.jetbrains\.kotlin\.plugin\.compose/.test(contents)) {
      contents = `apply plugin: 'org.jetbrains.kotlin.plugin.compose'\n` + contents;
    }
    contents = ensureAndroidBuildFeaturesCompose(contents);
    contents = ensureComposeDependencies(contents);
    appGradleConfig.modResults.contents = contents;
    return appGradleConfig;
  });

  return config;
};

const withReadyRemitSdk = (config) => {
  config = withReadyRemitGradleProps(config);
  config = withReadyRemitIos(config);
  config = withReadyRemitPodfile(config);
  config = withReadyRemitAndroidManifest(config);
  config = withReadyRemitAndroidCompose(config);
  return config;
};

module.exports = createRunOncePlugin(withReadyRemitSdk, 'readyremit-sdk-expo-plugin', '1.0.0');
