export { ReadyRemitEnvironment, ReadyRemitLocalization, ReadyRemitRemittanceServiceProvider, ReadyRemitTransferMethod, } from './types/ReadyRemit.types';
export type { ReadyRemitSourceAccount, ReadyRemitTokenResponse, ReadyRemitTransferResponse, ReadyRemitTransferRequestField, ReadyRemitTransferRequest, ReadyRemitError, } from './types/ReadyRemit.types';
export type { ReadyRemitConfiguration } from './types/ReadyRemitConfiguration.types';
export { ReadyRemitSupportedAppearance } from './types/ReadyRemitAppearance.types';
export type { ReadyRemitAppearance, ReadyRemitColorValue, ReadyRemitFoundations, ReadyRemitComponents, ReadyRemitButtonConfig, ReadyRemitInputFieldsConfig, ReadyRemitLoadingConfig, ReadyRemitBackLinkConfig, ReadyRemitContentConfig, ReadyRemitFontFamily, ReadyRemitTextCase, ReadyRemitBackIconType, ReadyRemitHomepageHeadline, ReadyRemitHomepageDescription, } from './types/ReadyRemitAppearance.types';
export { ReadyRemitDefaultCountry } from './types/ReadyRemitDefaultCountry.types';
export declare const startSDK: ({ configuration, fetchAccessTokenDetails, verifyFundsAndCreateTransfer, onLoad, onClose, }: {
    configuration: import(".").ReadyRemitConfiguration;
    fetchAccessTokenDetails: () => Promise<import(".").ReadyRemitTokenResponse | import(".").ReadyRemitError>;
    verifyFundsAndCreateTransfer: (request: import(".").ReadyRemitTransferRequest) => Promise<import(".").ReadyRemitTransferResponse | import(".").ReadyRemitError>;
    onLoad?: () => Promise<void>;
    onClose?: () => Promise<void>;
}) => void;
export declare const startTransferDetails: ({ transferId, configuration, fetchAccessTokenDetails, onLoad, onClose, }: {
    transferId: string;
    configuration: import(".").ReadyRemitConfiguration;
    fetchAccessTokenDetails: () => Promise<import(".").ReadyRemitTokenResponse | import(".").ReadyRemitError>;
    onLoad?: () => Promise<void>;
    onClose?: () => Promise<void>;
}) => void;
//# sourceMappingURL=index.d.ts.map