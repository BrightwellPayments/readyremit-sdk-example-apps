export declare enum ReadyRemitRemittanceServiceProvider {
    CONVERA = "convera",
    MASTERCARD = "mastercard",
    MONEY_GRAM = "moneyGram",
    VISA = "visa"
}
export declare enum ReadyRemitEnvironment {
    Production = "PRODUCTION",
    Sandbox = "SANDBOX"
}
export declare enum ReadyRemitLocalization {
    EN_US = "en-US",
    ES_MX = "es-MX"
}
export declare enum ReadyRemitTransferMethod {
    BANK_ACCOUNT = "bankAccount",
    CASH_PICKUP = "cashPickup",
    MOBILE_WALLET = "mobileWallet",
    PUSH_TO_CARD = "pushToCard"
}
export type ReadyRemitSourceAccount = {
    alias: string;
    balance: number;
    last4: string;
    sourceProviderId: string;
};
/**
 * Response interface for authentication token requests
 *
 * This interface represents the expected structure of a successful token response
 * that should be provided to the SDK when handling TOKEN_REQUESTED events.
 *
 * @public
 */
export interface ReadyRemitTokenResponse {
    accessToken: string;
    expiresIn: number;
    scope: string;
    tokenType: string;
}
/**
 * Response interface for successful transfer submissions
 *
 * This interface represents the structure of a successful transfer response
 * returned after a transfer has been processed.
 *
 * @public
 */
export interface ReadyRemitTransferResponse {
    transferId: string;
}
/**
 * Error interface for SDK operations
 *
 * This interface represents the structure of error responses that can occur
 * during SDK operations such as authentication or transfer processing.
 *
 * @public
 */
export interface ReadyRemitError {
    code: string;
    message: string;
}
/**
 * Request interface for transfer submission
 *
 * This interface defines the structure of transfer requests that will be sent
 * by the SDK.
 *
 *
 * @public
 */
export type ReadyRemitTransferRequest = {
    fields?: [ReadyRemitTransferRequestField] | undefined;
    quoteBy: string;
    quoteHistoryId: string;
    recipientAccountId?: string | undefined;
    recipientId: string;
    sourceAccountId?: string | undefined;
};
export type ReadyRemitTransferRequestField = {
    id: string;
    type: string;
    value: string;
};
//# sourceMappingURL=ReadyRemit.types.d.ts.map