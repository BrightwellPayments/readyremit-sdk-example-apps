import type { ReadyRemitEnvironment, ReadyRemitLocalization, ReadyRemitRemittanceServiceProvider, ReadyRemitSourceAccount, ReadyRemitTransferMethod } from './ReadyRemit.types';
import type { ReadyRemitAppearance } from './ReadyRemitAppearance.types';
import { ReadyRemitSupportedAppearance } from './ReadyRemitAppearance.types';
import type { ReadyRemitDefaultCountry } from './ReadyRemitDefaultCountry.types';
export type ReadyRemitConfiguration = {
    /** The environment where the SDK will operate (production or sandbox) */
    environment: ReadyRemitEnvironment;
    /**
     * Appearance configuration for customizing the SDK's visual theme.
     * This is a JSON object that will be passed directly to the native SDK.
     * When not provided, the SDK will use its default theme.
     *
     * @example
     * ```typescript
     * appearance: {
     *   foundations: {
     *     colorPrimary: { light: '#007AFF', dark: '#0A84FF' },
     *     fontFamily: 'inter'
     *   },
     *   components: {
     *     button: {
     *       buttonRadius: 8
     *     }
     *   }
     * }
     * ```
     */
    appearance?: ReadyRemitAppearance | null;
    /**
     * Supported appearance mode for the SDK.
     * Controls whether the SDK uses light theme, dark theme, or follows device settings.
     * Defaults to `device` when not specified.
     */
    supportedAppearance?: ReadyRemitSupportedAppearance;
    /** Default country to be pre-selected in country selection screens. Set to null for no default */
    defaultCountry?: ReadyRemitDefaultCountry | null;
    /** Idle timeout interval in seconds. Set to null to disable timeout */
    idleTimeoutInterval?: number | null;
    /** Localization setting for the SDK interface language */
    localization?: ReadyRemitLocalization;
    /** Preferred remittance service provider. Set to null to allow user selection */
    remittanceServiceProvider?: ReadyRemitRemittanceServiceProvider | null;
    /** Array of available source accounts for transfers. Set to null to fetch dynamically */
    sourceAccounts?: ReadyRemitSourceAccount[] | null;
    /** Preferred transfer method. Set to null to allow user selection */
    transferMethod?: ReadyRemitTransferMethod | null;
};
//# sourceMappingURL=ReadyRemitConfiguration.types.d.ts.map