/**
 * Color value for light and dark appearances
 *
 * @example
 * ```typescript
 * const color: ReadyRemitColorValue = {
 *   light: '#007AFF',
 *   dark: '#0A84FF'
 * };
 * ```
 */
export type ReadyRemitColorValue = {
    /** Hex color for light mode (e.g., '#FFFFFF') */
    light: string;
    /** Hex color for dark mode (e.g., '#000000') */
    dark: string;
};
/**
 * Font family options supported by the SDK
 */
export type ReadyRemitFontFamily = 'inter' | 'roboto' | 'source sans 3' | 'sf pro';
/**
 * Text case transformation options
 */
export type ReadyRemitTextCase = 'none' | 'capitalize' | 'uppercase' | 'lowercase';
/**
 * Back icon type options
 */
export type ReadyRemitBackIconType = 'arrow' | 'chevron';
/**
 * Homepage headline options
 */
export type ReadyRemitHomepageHeadline = 'Global transfer' | 'International & domestic transfers' | 'International transfers' | 'Send money internationally';
/**
 * Homepage description options
 */
export type ReadyRemitHomepageDescription = 'Send funds to your recipients with convenience and flexibility.' | 'Send money to friends and family in other countries';
/**
 * Foundation colors configuration
 *
 * Contains the core color tokens used throughout the SDK
 */
export type ReadyRemitFoundations = {
    /** Primary brand color */
    colorPrimary?: ReadyRemitColorValue;
    /** Primary text color */
    colorTextPrimary?: ReadyRemitColorValue;
    /** Secondary text color */
    colorTextSecondary?: ReadyRemitColorValue;
    /** Link text color */
    colorTextLink?: ReadyRemitColorValue;
    /** Foreground/surface color */
    colorForeground?: ReadyRemitColorValue;
    /** Background color */
    colorBackground?: ReadyRemitColorValue;
    /** Divider/separator color */
    colorDivider?: ReadyRemitColorValue;
    /** Success state color */
    colorSuccess?: ReadyRemitColorValue;
    /** Warning state color */
    colorWarning?: ReadyRemitColorValue;
    /** Danger/error state color */
    colorDanger?: ReadyRemitColorValue;
    /** Font family to use throughout the SDK */
    fontFamily?: ReadyRemitFontFamily;
};
/**
 * Button component configuration
 */
export type ReadyRemitButtonConfig = {
    /** Primary button background color */
    buttonPrimaryBackgroundColor?: ReadyRemitColorValue;
    /** Primary button text color */
    buttonPrimaryTextColor?: ReadyRemitColorValue;
    /** Secondary button border color */
    buttonSecondaryBorderColor?: ReadyRemitColorValue;
    /** Secondary button text color */
    buttonSecondaryTextColor?: ReadyRemitColorValue;
    /** Text case transformation for button labels */
    buttonTextCase?: ReadyRemitTextCase;
    /** Whether to show text shadow on primary buttons */
    buttonPrimaryTextShadow?: boolean;
    /** Button corner radius in dp/pt */
    buttonRadius?: number;
};
/**
 * Input field component configuration
 */
export type ReadyRemitInputFieldsConfig = {
    /** Input field border color */
    inputBorderColor?: ReadyRemitColorValue;
    /** Input field background color */
    inputBackgroundColor?: ReadyRemitColorValue;
    /** Input field corner radius in dp/pt */
    inputRadius?: number;
};
/**
 * Loading screen configuration
 */
export type ReadyRemitLoadingConfig = {
    /** Loading screen background color */
    loadingBackgroundColor?: ReadyRemitColorValue;
    /** Loading screen text color */
    loadingTextColor?: ReadyRemitColorValue;
    /** Loading spinner color */
    loadingSpinnerColor?: ReadyRemitColorValue;
};
/**
 * Back link/navigation configuration
 */
export type ReadyRemitBackLinkConfig = {
    /** Back button icon type */
    backIconType?: ReadyRemitBackIconType;
    /** Text case for back button label */
    backTextCase?: ReadyRemitTextCase;
};
/**
 * Content/copy configuration for the home screen
 */
export type ReadyRemitContentConfig = {
    /** Homepage headline text */
    contentHomepageHeadline?: ReadyRemitHomepageHeadline;
    /** Homepage description text */
    contentHomepageDescription?: ReadyRemitHomepageDescription;
};
/**
 * Components configuration
 *
 * Contains configuration for individual UI components
 */
export type ReadyRemitComponents = {
    /** Button styling configuration */
    button?: ReadyRemitButtonConfig;
    /** Input field styling configuration */
    inputFields?: ReadyRemitInputFieldsConfig;
    /** Loading screen configuration */
    loading?: ReadyRemitLoadingConfig;
    /** Back navigation configuration */
    backLink?: ReadyRemitBackLinkConfig;
    /** Content/copy configuration */
    content?: ReadyRemitContentConfig;
};
/**
 * Complete appearance configuration for the ReadyRemit SDK
 *
 * This object will be serialized to JSON and passed to the native SDK.
 * It follows the same structure as the SDK's internal configuration format.
 *
 * @example
 * ```typescript
 * const appearance: ReadyRemitAppearance = {
 *   foundations: {
 *     colorPrimary: { light: '#007AFF', dark: '#0A84FF' },
 *     colorBackground: { light: '#FFFFFF', dark: '#000000' },
 *     fontFamily: 'inter'
 *   },
 *   components: {
 *     button: {
 *       buttonPrimaryBackgroundColor: { light: '#007AFF', dark: '#0A84FF' },
 *       buttonRadius: 8
 *     }
 *   }
 * };
 * ```
 */
export type ReadyRemitAppearance = {
    /** Foundation/base design tokens */
    foundations?: ReadyRemitFoundations;
    /** Component-specific configurations */
    components?: ReadyRemitComponents;
};
/**
 * Supported appearance modes for the SDK
 *
 * - `light`: SDK will always use light theme
 * - `dark`: SDK will always use dark theme
 * - `device`: SDK will follow device/system appearance setting
 */
export declare enum ReadyRemitSupportedAppearance {
    /** Only light appearance is supported */
    Light = "light",
    /** Only dark appearance is supported */
    Dark = "dark",
    /** Both light and dark appearances are supported, follows device setting */
    Device = "device"
}
//# sourceMappingURL=ReadyRemitAppearance.types.d.ts.map